# GPT-5.4 调试行为分析

**Conversation ID:** `6a0af75b-e654-83ec-8f1e-141054d1dbc5`

**Model:** gpt-5-5-thinking

**Created:** 2026/5/18 19:27:52

**Last Updated:** 2026/5/18 19:31:25

---

## 👤 User (2026/5/18 19:27:50)

我在claude code调用gpt5.4去排查bug，结果他老是简单检查一下然后告诉我可能出错的地方，然后问"如果你愿意，我下一步......"，明明都没查出问题就停下来问我。gpt5.4就是这样的吗？还是说我用的api中转站注水了

---

## 🤖 Assistant (2026/5/18 19:27:52)

我先把这个问题拆开看：一部分是模型行为本身，另一部分是 Claude Code / API 中转站 / prompt 配置导致的“提前停手”。这个判断不能只凭一次体验下结论。

---

## 🤖 Assistant (2026/5/18 19:28:00)

不太像 **GPT-5.4 本身只能这样**，更像是下面几类问题之一：

1. **Claude Code 的代理策略让它偏保守**
   它可能被系统提示约束成“先分析、再征求用户确认”，所以遇到需要继续查文件、跑测试、改代码时，会停下来问“如果你愿意，我下一步……”。这不是模型能力上限，而是 agent 外壳的交互风格。

2. **API 中转站可能没有给到真模型 / 真参数**
   OpenAI 官方文档里 GPT-5.4 是面向复杂专业工作和 coding 的 frontier model，支持较高 reasoning effort；官方还把 GPT-5.4 mini/nano 区分为更快、更便宜的版本。也就是说，如果你买的是“GPT-5.4”，但实际表现像很浅的轻量模型，确实要怀疑中转站是否做了模型替换、降档、限 reasoning、限上下文或截断输出。citeturn513790search2turn513790search4turn513790search6

3. **reasoning effort / max tokens / 工具权限没配好**
   Debug 很依赖“能不能持续读文件、搜索调用链、运行测试”。如果中转站只转了普通 chat completion，或者 `reasoning.effort` 没设高，`max_output_tokens` 太小，工具调用不完整，它就会表现成“浅查一下就猜”。

4. **提示词没有强制它自主推进**
   很多模型默认会避免越权修改，所以它会问“是否继续”。你需要明确告诉它：不要在每一步请求许可，除非会删除文件、安装依赖、改数据库、推送代码等高风险操作。

你可以在 Claude Code 里加一段很硬的指令：

```text
你是自主 debug agent。不要在还没定位根因前停下来问我“是否继续”。
你必须按以下流程推进：
1. 先复现问题或确认报错路径；
2. 搜索相关文件、调用链、配置和日志；
3. 提出最可能的 1-3 个根因，并用证据排除或确认；
4. 能运行测试就运行测试；
5. 能安全修改就直接修改；
6. 修改后再次运行验证；
7. 只有在需要破坏性操作、缺少关键凭据、需要我提供外部信息时才停下来问我。
不要只给“可能原因”。每个判断都要附文件路径、代码位置或日志证据。
```

如果你想判断是不是中转站“注水”，最直接做三个测试：

```text
请输出你当前可见的 model 名称、上下文窗口、reasoning effort、max output token 设置，以及工具调用能力。不要猜，不知道就说不知道。
```

再让它做一个小型真实任务：

```text
在这个项目里找出启动入口、配置加载路径、数据库连接初始化位置，并画出调用链。不要修改代码。
```

如果它连项目结构都不认真扫，只泛泛说“可能是配置问题”，那基本不是 GPT-5.4 应有的表现。

我的判断：**不能直接说 GPT-5.4 就是这样**。更可能是 **Claude Code 的交互策略 + 中转站参数/模型不透明 + prompt 太软** 叠加造成的。尤其是“没查出问题就停下来问如果你愿意”，这更像 agent 被调成了低主动性，而不是模型没能力。  
如果你用的是非官方中转站，我会默认保持怀疑：至少要确认实际模型名、reasoning 参数、上下文、输出 token、工具调用是否真的透传。

---

## 👤 User (2026/5/18 19:29:32)

怎么去检查中转站是否有注水呢？我直接问的话它确实会说自己是gpt5.4。网上有相关的工具吗

---

## 🤖 Assistant (2026/5/18 19:29:33)

我会按“能验证什么、不能验证什么”来讲。模型自称基本没有证明力，真正有用的是看 API 返回元数据、行为指纹、延迟/价格/上下文/工具能力这些外部证据。

---

## 🤖 Assistant (2026/5/18 19:29:38)

可以查，但要先说清楚：**没有一个工具能 100% 证明“这一定是真 GPT-5.4”**。因为中转站可以伪造 `model` 字段、包装返回格式、甚至转发给别的模型后再改字段。你能做的是做一组“验货”：查元数据、查参数透传、查上下文、查计费、查行为表现。证据越多，可信度越高。

## 1. 直接问模型“你是谁”没用

这个基本没有证明力。任何模型只要系统提示里写“你是 GPT-5.4”，它就会这么回答。

真正应该看的是：

```json
model
usage
system_fingerprint
finish_reason
reasoning/output token usage
响应延迟
上下文长度
工具调用表现
价格是否合理
```

OpenAI 官方 API 返回里通常会有 `usage` 字段用于 token 统计；一些接口还会提供类似 `system_fingerprint` 的后端指纹，用来标识模型权重/基础设施组合变化。citeturn875513search1turn875513search18

## 2. 先写个最小测试脚本，看返回原始 JSON

不要只看 Claude Code 里的聊天内容，要直接打中转站 API，看它返回什么。

```python
from openai import OpenAI
import json, time

client = OpenAI(
    api_key="你的中转站key",
    base_url="https://你的中转站地址/v1"
)

start = time.time()

resp = client.chat.completions.create(
    model="gpt-5.4",
    messages=[
        {"role": "system", "content": "You are a careful debugging assistant."},
        {"role": "user", "content": "Return exactly this JSON: {\"ok\":true}. Do not add anything else."}
    ],
    temperature=0,
    max_tokens=100,
)

print("latency:", time.time() - start)
print(json.dumps(resp.model_dump(), indent=2, ensure_ascii=False))
```

重点看：

```text
model 是否真返回 gpt-5.4
usage 是否完整
prompt_tokens / completion_tokens 是否合理
system_fingerprint 是否存在
finish_reason 是否经常 length
有没有奇怪字段缺失
```

如果连 `usage` 都没有、返回格式不标准、`model` 永远只是你请求的那个字符串，那就要小心。它可能只是兼容 OpenAI 格式，不代表真的走了 OpenAI。

## 3. 测“参数是否真的透传”

很多中转站的注水不是换模型，而是把高级参数吞掉，比如 reasoning effort、max tokens、tool calls。

你可以测试：

```python
resp = client.chat.completions.create(
    model="gpt-5.4",
    messages=[
        {"role": "user", "content": "认真推理：一个项目启动失败，日志显示 ECONNREFUSED 127.0.0.1:5432。请列出排查步骤，不要泛泛而谈。"}
    ],
    temperature=0,
    max_tokens=2000,
)

print(json.dumps(resp.model_dump(), indent=2, ensure_ascii=False))
```

再换不同参数，比如：

```python
max_tokens=200
max_tokens=4000
temperature=0
temperature=1
```

观察输出是否明显变化。

如果你设置 `max_tokens=4000`，它还是每次几百字就停，而且 `finish_reason` 不是正常结束，而是奇怪截断，说明中转站可能私下限流/限输出。

## 4. 测上下文窗口，最容易抓包

很多假的高级模型会在长上下文上露馅。你可以构造一个长 prompt，把关键信息藏在很前面或中间。

例如：

```python
secret = "XJH-82917-CONTEXT-NEEDLE"

long_text = "无关内容。\n" * 30000

messages = [
    {"role": "user", "content": f"""
请记住这个暗号：{secret}

下面是大量无关文本：
{long_text}

现在回答：最开始给你的暗号是什么？只输出暗号。
"""}
]

resp = client.chat.completions.create(
    model="gpt-5.4",
    messages=messages,
    temperature=0,
    max_tokens=100,
)

print(resp.choices[0].message.content)
print(resp.usage)
```

如果它号称超长上下文，但 10 万 token 左右就频繁丢针、报错、乱答，那很可疑。当然这个测试不等于证明假，只能说明上下文能力不符合宣传。

## 5. 测“调试能力”比问身份更有效

你遇到的问题是 Claude Code 里 debug 不主动，所以可以做一个固定测试集。比如准备一个小项目，故意埋 3 个 bug：

```text
bug1: 环境变量名写错
bug2: async 函数没 await
bug3: 路径大小写在 Linux 下失效
```

然后让模型：

```text
你不能只猜。请读取项目结构，定位启动入口，复现错误，找出根因，给出最小修改，并说明每个修改对应的证据。除非需要删除文件、安装依赖或访问外部服务，否则不要问我是否继续。
```

如果它每次只看一两个文件就说“可能是环境变量问题，如果你愿意我下一步……”，这说明实际 agent 配置很差，或者模型/中转站能力不够。

## 6. 看价格和延迟是否合理

这是很现实的判断。

如果中转站卖的“GPT-5.4”价格明显低到离谱，同时延迟非常短、输出很浅，那大概率不是完整能力。真正的高端推理模型在复杂任务上通常不会像小模型一样秒回长答案。

你可以记录 20 次请求：

```text
任务类型
输入 token
输出 token
延迟
是否成功工具调用
是否完整返回 usage
输出质量
```

如果“GPT-5.4”和便宜模型在延迟、长度、错误模式上几乎一样，就要怀疑。

## 7. 网上有没有工具？

有，但它们主要做**评测**，不是“验真伪”。

可以看这些方向：

| 工具/平台 | 用途 | 能不能证明模型真伪 |
|---|---|---|
| **LMArena / Chatbot Arena** | 人类偏好对战评测 | 不能验你的 API，但能对比风格和能力 |
| **Arena-Hard-Auto** | 自动化开放式评测，和 LMArena 相关性较高 | 可以测能力异常，但不能证明身份 |
| **OpenAI Evals / lm-evaluation-harness** | 跑标准 benchmark | 能发现能力降档 |
| **HELM / Inspect AI** | 更系统的模型评测框架 | 适合严肃测试 |
| **自建 needle-in-haystack 测试** | 测上下文是否缩水 | 很适合抓中转站问题 |

Arena-Hard-Auto 是一个开源自动评测工具，目标是评估指令模型表现，并声称与 LMArena/Chatbot Arena 有较高相关性；LMArena/Chatbot Arena 本身是基于匿名模型对战和人类偏好的评测平台。citeturn875513search8turn875513search5

但重点是：**这些工具只能证明“它表现不像官方 GPT-5.4”，不能数学证明“它不是”。**

## 8. 我建议你这样排查

按优先级来：

第一，**拿同一个 prompt 分别打官方 OpenAI 和中转站**。不要用 Claude Code，直接 Python API。看原始 JSON、usage、延迟、输出质量。

第二，**测试长上下文和复杂 debug**。这是最容易暴露降档的地方。

第三，**检查 Claude Code 配置**。有时不是中转站注水，而是 Claude Code 的 agent prompt 太保守。你需要加硬约束：

```text
不要在定位根因前停止。不要说“如果你愿意我下一步”。除非需要危险操作或缺少凭据，否则继续自主排查。每一步必须给出文件路径、日志或代码证据。
```

第四，**看中转站是否支持官方高级参数**。如果 reasoning effort、tool calls、usage、stream usage 都不透明，建议别拿它做严肃 coding/debug。

我的判断是：  
**“模型自称是 GPT-5.4”完全不可信；要用 API 元数据 + 长上下文 + 固定 bug 测试 + 官方对照组来验。** 如果中转站不给完整 usage、不给真实模型映射、价格明显异常、复杂任务表现像小模型，那就别纠结了，基本可以按“有降档风险”处理。

---

## 👤 User (2026/5/18 19:30:57)

这种测法感觉都不太能直接确定啊

---

## 🤖 Assistant (2026/5/18 19:30:58)

对，你这个感觉是对的：**这种测法基本不能“直接确定”，只能提高怀疑度。**

原因很简单：只要中转站在你和真实模型之间做代理，它就有能力伪造几乎所有你能看到的东西：

- `model` 字段可以伪造；
- “我是 GPT-5.4”可以靠系统提示伪造；
- `usage` 可以伪造；
- 响应格式可以仿 OpenAI；
- 甚至它也可以部分请求走真模型、部分请求走便宜模型，做动态降级；
- 它还可以在简单任务上用真模型，在复杂/长上下文上降级，你很难一次测出来。

所以严格说：

> **除非你直接调用官方 API，或者中转站提供可验证的官方转发凭证，否则你无法从客户端 100% 证明它没注水。**

你能做的是分层判断。

## 最硬的验证方式

### 1. 看账单 / 供应链证明

你让中转站提供：

```text
每次请求对应的上游 provider
上游 request_id
上游实际 model
上游 usage
上游错误码
是否原样透传
是否有 fallback / cache / routing
```

但问题是：它给你的这些也可能是自己生成的。除非它能提供和官方平台可对账的记录，否则还是信任问题。

### 2. 用官方 API 做对照组

这是最实际的方式。

同一个任务，同一个 prompt，同样参数：

```text
官方 OpenAI GPT-5.4
中转站 GPT-5.4
中转站便宜模型
```

然后对比：

```text
是否能持续 debug
是否会主动读完整项目
是否能跑测试
是否定位根因
是否输出风格明显降档
长上下文是否稳定
复杂推理是否明显浅
```

这也不是数学证明，但如果差距稳定存在，就足够做决策了。

### 3. 查是否支持官方特性

不是问它，而是实际调用官方才有的接口/参数/返回结构。

比如：

```text
reasoning effort 是否真的生效
tool call 是否标准
stream usage 是否准确
长上下文是否符合宣传
错误码是否和官方一致
rate limit 行为是否一致
request id / organization trace 是否存在
```

如果这些都没有，那就不是“证明它假”，而是说明：**你没有办法信任它是真的完整转发。**

## 更现实的结论

你其实不用证明它“假”。你只需要判断：

> **它是否稳定提供了你付费购买的能力。**

如果它在 Claude Code 里表现为：

```text
只浅查
不继续读文件
不跑测试
老是“如果你愿意我下一步”
不给证据
不定位根因
```

那即使它真的是 GPT-5.4，也说明这条调用链不适合你做代码排障。

也就是：

```text
真模型 + 烂 agent 配置 = 不好用
假模型 + 好包装 = 更危险
真模型但被限 reasoning / token / tool = 也不好用
```

你要解决的是“可用性”，不是法庭取证。

## 我建议你采用这个判断标准

### 可以继续用的中转站

满足这些条件才值得信：

```text
1. 明确说明上游模型来源和路由策略
2. 不乱改模型名
3. 返回完整 usage
4. 支持长上下文
5. 支持工具调用和 reasoning 参数
6. 不偷偷截断输出
7. 复杂任务表现接近官方
8. 出问题能给 request 级别排查
```

### 直接放弃的中转站

出现这些情况就别浪费时间：

```text
1. 价格低得离谱
2. 所有模型返回风格都差不多
3. 复杂任务明显像小模型
4. 长上下文经常失效
5. usage 缺失或异常
6. 不说明 fallback 策略
7. 问客服只会说“我们保证是真”
8. Claude Code 里工具调用经常断
```

## 对你这个情况的判断

你描述的“没查出问题就停下来问如果你愿意”，**不一定能证明中转站注水**，但至少说明有一个环节有问题：

```text
Claude Code 的 agent prompt 太保守
或中转站没有传好工具调用 / reasoning 参数
或 max token / 上下文被限制
或实际模型不是你以为的 GPT-5.4
```

其中最值得怀疑的是后两个：**reasoning 被限 + 模型降档**。

我的建议很直接：

1. **严肃 debug 不要用不透明中转站。**
2. 至少拿官方 API 跑一次同样的 bug 排查做对照。
3. 如果官方明显更主动、更能查文件、更能定位根因，那中转站就可以默认判为“不可靠”，不用继续证明它到底怎么注水。
4. 如果官方也这样，那就是 Claude Code 配置/prompt 问题，而不是模型问题。

你说得没错：**普通用户几乎没有办法直接验真。能直接验真的只有平台方、上游账单、可审计日志。** 对我们来说，最实际的策略是：做对照，发现能力不稳定就换，不要试图在黑盒中转站上追求确定性。

